is.dppm <- function#Recognise Fitted Determinantal Point Process Models
### Check that an object inherits the class dppm
(x
 ### Any object.
 ){
    inherits(x, "dppm")
    ### A single logical value.

    ##keyword<< spatial
    ##keyword<< manip
    ##keyword<< models
}
